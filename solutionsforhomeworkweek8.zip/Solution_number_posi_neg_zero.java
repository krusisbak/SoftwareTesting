package if_condition;

public class number_posi_neg_zero {

	public static void main(String[] args) {
	
		int x = 5
		
		if (x < 0)
			System.out.println("Number is negative..");
		else if (x > 0)			
			System.out.println("Number is positive....");
		else
			System.out.println("Number is zero...");

	}

}
