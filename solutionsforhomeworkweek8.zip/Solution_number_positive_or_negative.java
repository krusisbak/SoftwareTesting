package if_condition;

public class number_positive_or_negative {
	public static void main (String args[])
	{
		
		int x = 25;
		
		if (x < 0)
			System.out.println("Number is negative..");
		else (x > 0)
			System.out.println("Number is positive....");
		
	}

}
