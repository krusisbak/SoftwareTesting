package if_condition;

public class even_odd {

	public static void main(String[] args) {

		int x = 55;
		
		if (x % 2 == 0)
			System.out.println("Entered number is even");
		else
			System.out.println("Entered number is odd");	
	}

}
