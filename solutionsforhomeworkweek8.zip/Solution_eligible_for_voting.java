package if_condition;

public class eligible_for_voting {
	public static void main (String args[])
	{
		int age=10;
		
		if (age < 18)
			System.out.println("You are not eligible for voting...");
		else
			System.out.println("You are eligible for voting...");
		
		
	}

}
