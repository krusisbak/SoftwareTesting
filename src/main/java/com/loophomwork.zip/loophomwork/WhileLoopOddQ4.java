package com.loophomwork;

public class WhileLoopOddQ4 {
    public static void main (String[] args){
        System.out.println("List of 10 Odd number");
            int i = 0;
            while (i <= 20) {
                if (i % 2 != 0) {
                    System.out.println(" " + i);
                }  i++;
            }
        }
        }

//This programing is also running but when we change number it can become even as well.
//System.out.println("List of 10 Odd Numbers");
//int i = 1;
//int num = 1;
//while (i <=10) {
//  System.out.println(num);
//i+=1;
//num+=2;
