package com.loophomwork;

public class DoWhileLoopEvenNumberQ6 {
    public static void main(String[] args) {
        System.out.println("List of 10 Even number");
        int i = 0;
        do {
            if (i % 2 == 0) {
                System.out.println(" " + i);
            }   i++;
            } while (i <= 20);
        }
    }

