package com.loophomwork;

public class WhileLoopEvenQ4 {
    public static void main(String[] args) {
        System.out.println("List of 10 Even number");
        int i = 1;
        while (i <= 20) {
            if (i % 2 == 0) {
                System.out.println(" " + i);
            }  i++;
        }
    }
}



