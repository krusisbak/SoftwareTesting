package com.loophomwork;

public class DoWhileLoopTableOf8Q7 {
    public static void main(String[] args) {
        System.out.println("Table of 8");
        int i = 1;
        int k = 8;

        do {
            System.out.println(k + " * " + i + " = " + (i * k));
            i++;
        } while (i <= 10);
        }
    }
