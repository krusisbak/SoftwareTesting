package com.loophomwork;

public class WhileLoopTableFor9Q5 {
    public static void main (String [] args) {
        System.out.println("Table of 9");
        int i = 1;
        int k = 9;

        while(i<=10)  {
            System.out.println(k+" * " + i+" = " + (i * k));
             i++;

        }

    }

}
