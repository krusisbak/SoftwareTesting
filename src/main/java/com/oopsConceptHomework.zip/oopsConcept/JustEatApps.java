package oopsConcept;

public class JustEatApps extends FoodApps {
    @Override
    public void deliveryWrap() {
        System.out.println("Delivery delicious Spring Roll");
    }

    public void deliveryIceCream() {
        System.out.println("Delivery delicious Kulfi");
    }
}

