package oopsConcept;

public class FoodApps {

    public void deliveryWrap() {
        System.out.println("Delivery delicious Veg Roll");
    }
    public void deliverySandwich() {
        System.out.println("Delivery delicious Cheese Ploughman");
    }
    public void deliveryBurger() {
        System.out.println("Delivery delicious Vada Pav");
            }
        }


