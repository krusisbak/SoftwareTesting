package oopsConcept;

public class UberApps extends FoodApps{
    @Override
    public void deliveryBurger() {
        System.out.println("Delivery delicious Samosa Pav");
    }

    public void deliveryPizza() {
        System.out.println("Delivery delicious Veg Pizza");
    }
}
