package oopsConcept;

public class MobilePhone {
    String mobileName;
    String Colour;
    boolean simFree;
    String operatingSystem;
    double displayInchSize;
    int capacityRam;

}
