package com.classhomework;

public class DataTypesArithmetic7 {
    //character
    public static void main (String [] args){
        char alpha = 'J';
        char a = 65;
        char b = 66;
        char c = 67;
        System.out.println(a);

    }
}
