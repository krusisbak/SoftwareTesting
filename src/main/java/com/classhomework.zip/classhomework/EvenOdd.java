package com.classhomework;

public class EvenOdd {
    public static void main(String[] args) {
        int mix = 10;

        if (mix % 2 == 0) {
            System.out.println("Number is even");
        } else {
            System.out.println("Number is odd");
        }
    }
}




