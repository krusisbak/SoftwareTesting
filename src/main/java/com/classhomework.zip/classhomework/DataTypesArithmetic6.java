package com.classhomework;

public class DataTypesArithmetic6 {
    //float number example
    public static void main (String [] args){
        float num = 35;
        System.out.println(num);
    }
}
