package com.classhomework;

public class PositiveNegative {
    public static void main (String []args){
        int positive = 10;
        int negative = -1;
        if (positive > negative) {
            System.out.println("Number is Positive");
        }
        else if ( positive < negative) {
            System.out.println("Number is Negative");
        }
        else{
            System.out.println("Value is Zero");
        }


    }
}
