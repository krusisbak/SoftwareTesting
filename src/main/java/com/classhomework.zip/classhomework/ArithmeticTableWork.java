package com.classhomework;

public class ArithmeticTableWork {
    // Arithmetic operation
    public static void main (String [] args){
        int m = 18;
        int n = 7;
        int result1;
        int result2;
        //addition operator
        System.out.println(m + n);

        //subtraction operator
        System.out.println(m-n);

        //multiplication operator
        System.out.println(m*n);

        //division operator
        System.out.println(m/n);

        //module operator
        System.out.println(m%n);

        //increment operator
        result1 = ++m;
        System.out.println("After increment:"+m);

        //decrement operator
        result2 = --n;
        System.out.println("After decrement:" +n);



    }



}
