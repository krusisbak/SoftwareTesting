package com.classhomework;

public class DataTypesArithmetic3 {
    public static void main (String [] args){
        //integer example
        int num = 123456789;
        System.out.println(num);
    }

}
