package com.classhomework;

public class DataTypesArithmetic5 {
    // double number example
    public static void main (String [] args){
        double num = 89.23d;
        System.out.println(num);
    }
}
